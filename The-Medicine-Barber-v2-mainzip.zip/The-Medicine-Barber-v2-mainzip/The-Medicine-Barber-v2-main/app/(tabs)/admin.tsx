import React from 'react';
import AdminScreen from '../screens/AdminScreen';

export default function AdminTab() {
  return <AdminScreen />;
}
