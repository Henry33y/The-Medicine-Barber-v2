import React from 'react';
import ServicesScreen from '../screens/ServicesScreen';

export default function ServicesTab() {
  return <ServicesScreen />;
}
