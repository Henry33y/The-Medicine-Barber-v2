# Street Urban Barber - Mobile Appointment Booking App

## Overview

Street Urban Barber is a React Native mobile application built with Expo that enables customers to book barbershop appointments and make online payments. The app serves a single barbershop location, allowing users to browse services, select time slots, and complete bookings with integrated payment processing. The application features role-based access with both customer and admin views for managing the barbershop's daily operations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React Native with Expo SDK 54
- File-based routing via `expo-router` v6 with typed routes
- Tab-based navigation structure using `@react-navigation/bottom-tabs`
- Platform-adaptive UI components with light/dark theme support
- Haptic feedback integration for iOS devices

**Navigation Structure**:
- Tab-based bottom navigation with Home, Services, My Appointments, and Admin (role-gated) tabs
- Stack-based routing for booking flow, checkout, profile management
- Authentication gate at root layout level that redirects unauthenticated users to `/auth`
- Splash screen that transitions to auth flow on app launch

**UI Patterns**:
- Themed components (`ThemedText`, `ThemedView`) that adapt to system color scheme
- Parallax scroll views for enhanced visual experience
- Collapsible sections for organizing content
- Platform-specific icon systems (SF Symbols on iOS, Material Icons on Android/Web)

**State Management Approach**:
- Session state managed via Supabase Auth's built-in session persistence
- Local component state with React hooks
- Auth state changes monitored through `onAuthStateChange` listener at root layout
- Dependencies include React Query and Zustand (optional, per package.json) but not actively implemented

### Backend Architecture

**Backend-as-a-Service**: Supabase (PostgreSQL + Auth + Storage)
- Database: PostgreSQL hosted on Supabase
- Authentication: Supabase Auth with email/password and Google OAuth via PKCE flow
- Real-time capabilities: Available but not currently utilized
- Session management: Persistent sessions with auto-refresh tokens

**Database Schema** (Partial - from README):
- `profiles` table: User profile information (id, full_name, phone, role)
  - `role` field supports 'user' or 'admin' for access control
  - Primary key `id` matches Supabase Auth user ID
- `services` table: Barbershop services catalog (id, name, price)
  - Pricing stored as numeric type in GHS currency

**Authentication Flow**:
1. AuthGate component at root layout checks session on mount
2. Unauthenticated users redirected to `/auth` screen
3. Email/password or Google OAuth sign-in via Supabase Auth
4. Google OAuth uses `expo-auth-session` with PKCE flow
5. Redirect URI dynamically computed using `makeRedirectUri` (proxy-aware for Expo Go)
6. Session persistence enabled via AsyncStorage
7. Auth state changes trigger navigation updates

**Authorization Pattern**:
- Role-based access control via `profiles.role` field
- Admin tab visibility gating mentioned but not fully implemented in current codebase
- Profile data fetched post-authentication to determine user role

### Payment Integration

**Payment Provider**: Paystack
- Implementation: Inline Checkout or WebView integration
- Payment methods: Card and mobile money support
- Integration point: `/checkout` route after appointment booking

### Mobile Platform Support

**Target Platforms**:
- iOS (supports tablets)
- Android (package: `com.henry.medicinebarber`)
- Web (static output)

**Platform-Specific Configurations**:
- Android: Adaptive icons with foreground/background/monochrome variants, edge-to-edge enabled
- iOS: Universal device support, haptic feedback, SF Symbols
- Deep linking: Custom scheme `medicinebarber://`

**Build System**: EAS (Expo Application Services)
- Development builds with internal distribution
- Production builds with auto-increment versioning
- App version source set to remote

## External Dependencies

### Core Services

1. **Supabase** (`@supabase/supabase-js` v2.81.0)
   - URL: `https://eldezufspaabepzoaesq.supabase.co` (configured in app.json)
   - Anon key required via environment variables
   - Services used: PostgreSQL database, Authentication, potential Storage
   - Configuration: Environment variables via `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`

2. **Paystack**
   - Payment gateway for Ghana-based transactions
   - Implementation: WebView or inline checkout (not yet visible in repository)
   - Currency: GHS (Ghana Cedis)

3. **Google OAuth**
   - Provider: Google Sign-In via Supabase Auth
   - Flow: PKCE (Proof Key for Code Exchange) for mobile security
   - Redirect handling: `expo-auth-session` with dynamic URI construction

### Key NPM Packages

**Navigation & Routing**:
- `expo-router` v6.0.14 (file-based routing)
- `@react-navigation/native` v7.1.8
- `@react-navigation/bottom-tabs` v7.4.0
- `react-native-screens` v4.16.0
- `react-native-safe-area-context` v5.6.0

**Expo SDK Modules**:
- `expo-auth-session` v7.0.8 (OAuth flows)
- `expo-web-browser` v15.0.9 (in-app browser for external links)
- `expo-linking` v8.0.8 (deep linking)
- `expo-constants` v18.0.10 (environment config access)
- `expo-haptics` v15.0.7 (tactile feedback)
- `expo-image` v3.0.10 (optimized image component)

**UI & Animation**:
- `react-native-reanimated` v4.1.1 (animations)
- `react-native-gesture-handler` v2.28.0 (gesture system)
- `expo-symbols` v1.0.7 (SF Symbols for iOS)
- `@expo/vector-icons` v15.0.3 (icon library)

**Data & Storage**:
- `@react-native-async-storage/async-storage` v2.2.0 (local storage)
- `@react-native-community/datetimepicker` v8.4.4 (date/time selection)

**Development**:
- TypeScript v5.9.2 with strict mode enabled
- ESLint v9.25.0 with Expo config
- React 19.1.0 (latest stable)
- React Native 0.81.5

### Environment Configuration

Required environment variables (via `app.json` extra or `.env`):
- `EXPO_PUBLIC_SUPABASE_URL`: Supabase project URL
- `EXPO_PUBLIC_SUPABASE_ANON_KEY` or `EXPO_PUBLIC_SUPABASE_KEY`: Supabase anonymous key
- Paystack configuration: Not yet defined in codebase

Configuration priority (in `lib/supabaseClient.js`):
1. Process environment variables (`process.env.EXPO_PUBLIC_*`)
2. Expo Constants extra config (`app.json` extra field)
3. Legacy manifest extra