import React from 'react';
import MyAppointmentsScreen from '../screens/MyAppointmentsScreen';

export default function MyAppointmentsTab() {
  return <MyAppointmentsScreen />;
}
