import AuthScreen from '@/app/screens/AuthScreen';
import React from 'react';

export default function AuthRoute() {
  return <AuthScreen />;
}
