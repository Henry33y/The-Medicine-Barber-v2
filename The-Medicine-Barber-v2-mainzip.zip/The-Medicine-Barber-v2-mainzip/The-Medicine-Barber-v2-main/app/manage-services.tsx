import React from 'react';
import ManageServicesScreen from './screens/ManageServicesScreen';

export default function ManageServicesRoute() {
  return <ManageServicesScreen />;
}
