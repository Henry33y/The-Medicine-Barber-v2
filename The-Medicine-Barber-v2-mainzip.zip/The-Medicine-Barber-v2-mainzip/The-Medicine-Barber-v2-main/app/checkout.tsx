import React from 'react';
import CheckoutScreen from './screens/CheckoutScreen';

export default function CheckoutRoute() {
  return <CheckoutScreen />;
}
