import React from 'react';
import HomeScreen from '../screens/HomeScreen';

export default function HomeTab() {
  return <HomeScreen />;
}
