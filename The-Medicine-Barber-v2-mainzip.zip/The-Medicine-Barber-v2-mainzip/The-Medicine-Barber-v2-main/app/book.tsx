import React from 'react';
import BookingScreen from './screens/BookingScreen';

export default function BookRoute() {
  return <BookingScreen />;
}
